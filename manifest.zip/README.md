
<h1 align="center">
  <br>
  <a href=""><img src="https://raw.githubusercontent.com/TiramisuAddict/FGR-sidebar-remover/c398bd1e4fb6ac7377e6c18000fe5c20bdd1aae7/ui/FGRR.svg" alt="logo" width="200"></a>
  <br>
    FGR sidebar remover
  <br>
</h1>

<h4 align="center">FitGirl-Repacks Sidebar Remover is a simple browser extension that hides the inappropriate and distracting sidebar content on the FitGirl Repacks website, offering a cleaner and more enjoyable browsing experience.</h4>
